#!/bin/bash
ibus-table-createdb -s ./98wubi.txt -n 98wubi.db&&cp ./98wubi.db /usr/share/ibus-table/tables/&&cp ./wubi.svg /usr/share/ibus-table/icons/&&killall ibus-daemon|ibus-daemon -d
